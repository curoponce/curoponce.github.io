<?php $__env->startSection('content'); ?>
<!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">DashBoard</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item active">DashBoard</li>
                        </ol>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->

                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-block">
                                <div class="d-flex flex-row">
                                    <div class="round align-self-center round-success"><i class="mdi mdi-buffer"></i></div>
                                    <div class="m-l-10 align-self-center">
                                        <h3 class="m-b-0"><?php echo e($articulos); ?></h3>
                                        <h5 class="text-muted m-b-0">Articulos</h5></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-block">
                                <div class="d-flex flex-row">
                                    <div class="round align-self-center round-info"><i class="mdi mdi-account-multiple"></i></div>
                                    <div class="m-l-10 align-self-center">
                                        <h3 class="m-b-0"><?php echo e($clientes); ?></h3>
                                        <h5 class="text-muted m-b-0">Clientes</h5></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-block">
                                <div class="d-flex flex-row">
                                    <div class="round align-self-center round-danger"><i class="mdi mdi-cart"></i></div>
                                    <div class="m-l-10 align-self-center">
                                        <h3 class="m-b-0"><?php echo e($ventas); ?></h3>
                                        <h5 class="text-muted m-b-0">Ventas Realizadas</h5></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-block">
                                <div class="d-flex flex-row">
                                    <div class="round align-self-center round-success"><i class="mdi mdi-clipboard-text"></i></div>
                                    <div class="m-l-10 align-self-center">
                                        <h3 class="m-b-0"><?php echo e($ingresos); ?></h3>
                                        <h5 class="text-muted m-b-0">Ingresos de mercaderia</h5></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                
                <!-- Column -->
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title">Disponibilidad de productos</h4>
                                <table id="demo-foo-addrow2" class="table table-bordered table-hover toggle-circle" data-page-size="7">
                                    <div class="d-flex">
                                        <div class="ml-auto">
                                            <div class="form-group">
                                                <input id="demo-input-search2" type="text" placeholder="Search" class="form-control" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <thead>
                                        <tr>
                                            <th data-sort-initial="true" data-toggle="true">Imagen</th>
                                            <th>Nombre, Descripcion y codigo</th>
                                            <th data-hide="phone, tablet">Cantidad </th>
                                            <th data-hide="phone, tablet">Precio</th>
                                            <th data-hide="phone, tablet">Estado</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a class="image-popup-no-margins" href="<?php echo e(asset('imagenes/articulos/'.$list -> imagen)); ?>" title="<?php echo e($list -> nombre); ?>">
                                                        <img src="<?php echo e(asset('imagenes/articulos/'.$list -> imagen)); ?>" alt="<?php echo e($list -> nombre); ?>" height="50px" width="50px" class="img-thumbnail" class="img-responsive" >
                                                    </a>
                                                </td>
                                                <td>
                                                    <h6><a href="javascript:void(0)" class="link"><?php echo e($list->nombre); ?>, <?php echo e($list->descripcion); ?></a></h6><small class="text-muted">Codigo del producto :  <?php echo e($list->codigo); ?> </small>
                                                </td>

                                                
                                                <td>
                                                    <?php if($list->stock < 20 && $list->estado == "Inactivo"): ?>
                                                        <h5> 
                                                            <a data-toggle="tooltip" title="Este articulo se esta agotando y se encuentra Inactivo para su venta">
                                                                <i class="ti-arrow-down text-danger"></i> &nbsp; <?php echo e($list->stock); ?>

                                                            </a>
                                                        </h5>

                                                        <?php else: ?>
                                                            <?php if($list->stock > 20 && $list->estado == "Activo"): ?>
                                                            <h5> 
                                                                <a data-toggle="tooltip" title="Este producto aún esta disponible y se encuentra Activo para la venta">
                                                                    <i class="ti-arrow-up text-success"></i> &nbsp; <?php echo e($list->stock); ?>

                                                                </a>
                                                            </h5>
                                                            <?php else: ?>
                                                                <?php if($list->stock > 20 && $list->estado == "Inactivo"): ?>
                                                                <h5> 
                                                                    <a data-toggle="tooltip" title="Este producto aún esta disponible, pero se encuentra Inactivo para su venta">
                                                                        <i class="ti-arrow-up text-success"></i> &nbsp; <?php echo e($list->stock); ?>

                                                                    </a>
                                                                </h5>
                                                                <?php else: ?>
                                                                    <?php if($list->stock < 20 && $list->estado == "Activo"): ?>
                                                                    <h5> 
                                                                        <a data-toggle="tooltip" title="Este producto se esta agotando, pero aun esta activo para su venta">
                                                                            <i class="ti-arrow-down text-danger"></i> &nbsp; <?php echo e($list->stock); ?>

                                                                        </a>
                                                                    </h5>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <h5>S/. <?php echo e($list->precio_venta); ?>.00</h5>
                                                </td>

                                                <?php if($list->estado == "Activo"): ?>
                                                <td>
                                                    <span class="label label-table label-success"><?php echo e($list->estado); ?></span> 
                                                </td>
                                                <?php else: ?>
                                                <td>
                                                    <span class="label label-table label-danger"><?php echo e($list->estado); ?></span> 
                                                </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="6">
                                                <div class="text-right">
                                                    <ul class="pagination">

                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>