<?php $__env->startSection('content'); ?>
<!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Venta</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item active">Detalle de venta</li>
                        </ol>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card card-block printableArea">
                            <h3><b><?php echo e($venta -> tipo_comprobante); ?></b> <span class="pull-right">Serie: <?php echo e($venta -> serie_comprobante); ?> y #<?php echo e($venta -> num_comprobante); ?></span></h3>
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="pull-left">
                                        <address>
                                            <h3> &nbsp;<b class="text-danger">Monster Admin</b></h3>
                                            <p class="text-muted m-l-5">Cliente: <?php echo e($venta -> nombre); ?> <?php echo e($venta -> a_paterno); ?></p>
                                        </address>
                                    </div>
                                    <div class="pull-right text-right">
                                        <address>
                                            <h4 class="font-bold">Curo Motor's</h4>
                                            <p class="text-muted m-l-30">Av.Mariscal Benavides s/n,
                                                <br/> Referencia : Al costado de grifo castillo
                                            </p>
                                        </address>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="table-responsive m-t-40" style="clear: both;">
                                        <table class="table table-hover">
                                            <thead>
                                                <th>Artículo</th>
                                                <th>Cantidad</th>
                                                <th>Precio venta</th> 
                                                <th>Descuento</th>                            
                                                <th>Subtotal</th>
                                            </thead>
                                            <tbody>
                                                 <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($det -> articulo); ?></td>
                                                        <td><?php echo e($det -> cantidad); ?></td>
                                                        <td>S/. <?php echo e($det -> precio_venta); ?></td>                               
                                                        <td>S/. <?php echo e($det -> descuento); ?></td>                               
                                                        <td>S/. <?php echo e($det -> cantidad * $det -> precio_venta); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="pull-right m-t-30 text-right">
                                        <!--
                                        <p>Sub - Total amount: $13,848</p>
                                        <p>vat (10%) : $138 </p>
                                        -->
                                        <h3><b>Total : </b>S/.<?php echo e($venta -> total_venta); ?></h3>
                                    </div>
                                    <div class="clearfix"></div>
                                    <hr>
                                    <div class="text-right">
                                        <button id="print" class="btn btn-default btn-outline" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>