 
 <?php $__env->startSection('content'); ?>
 <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Articulos</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item active">Lista de articulos</li>
                        </ol>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title">Listado de Articulos <button class="btn btn-outline-primary btn-rounded" data-toggle="modal" data-target="#modalcrear"><i class="fa fa-check"></i>Nuevo</button></h4>
                                <hr>
                                <?php if(Session::has('crear')): ?>
                                <div class="alert alert-success alert-rounded"> <i class="fa fa-check"></i> <strong>Felicidades</strong> <?php echo e(Session::get('crear')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                                </div>
                                <?php endif; ?>
                                <?php if(Session::has('actualizar')): ?>
                                <div class="alert alert-info alert-rounded"> <i class="fa fa-update"></i> <strong>Felicidades</strong> <?php echo e(Session::get('actualizar')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                                </div>
                                <?php endif; ?>
                                <?php if(Session::has('borrar')): ?>
                                <div class="alert alert-danger alert-rounded"> <i class="fa fa-warning"></i> <strong>Ops!</strong> <?php echo e(Session::get('borrar')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                                </div>
                                <?php endif; ?>
                                <div class="table-responsive m-t-40">
                                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Nombre</th>
                                                <th>Codigo</th>
                                                <th>Categoria</th>
                                                <th>Stock</th>
                                                <th>Precio de venta</th>
                                                <th>Imagen</th>
                                                <th>Estado</th>
                                                <th>Opciones</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>ID</th>
                                                <th>Nombre</th>
                                                <th>Codigo</th>
                                                <th>Categoria</th>
                                                <th>Stock</th>
                                                <th>Precio de venta</th>
                                                <th>Imagen</th>
                                                <th>Estado</th>
                                                <th>Opciones</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($art -> id_articulo); ?></td>
                                                <td><?php echo e($art -> nombre); ?></td>
                                                <td><?php echo e($art -> codigo); ?></td>
                                                <td><?php echo e($art -> categoria); ?></td>
                                                <td><?php echo e($art -> stock); ?></td>
                                                <td>S/. <?php echo e($art -> precio_venta); ?>.00</td>
                                                <td>
                                                    <img src="<?php echo e(asset('imagenes/articulos/'.$art -> imagen)); ?>" alt="<?php echo e($art -> nombre); ?>" height="50px" width="50px" class="img-thumbnail">                    
                                                </td>
                                                <td><?php echo e($art -> estado); ?></td>
                                                <td>
                                                    
                                                    <a data-toggle="tooltip" title="Editar Articulo" href="<?php echo e(URL::action('ArticuloController@edit', $art -> id_articulo)); ?>">
                                                        <button type="button" class="btn btn-info btn-circle"><i class="fa fa-pencil" data-toggle="modal" data-target="#modalEditar"></i> </button>
                                                    </a>
                                                    <a data-toggle="tooltip" title="Eliminar Articulo">
                                                        <button type="button" class="btn btn-danger btn-circle" data-toggle="modal" data-target="#modalEliminar-<?php echo e($art -> id_articulo); ?>"><i class="fa fa-times"></i> </button>
                                                    </a>
                                                </td>
                                            </tr>

                                            
                                            <!-- Modal Eliminar -->
                                                <!-- ============================================================== -->
                                                <div class="col-md-4">
                                                    <!-- sample modal content -->
                                                    <div id="modalEliminar-<?php echo e($art -> id_articulo); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                    <h4 class="modal-title">Eliminar Articulo <?php echo e($art->nombre); ?></h4>
                                                                </div>
                                                                <hr>
                                                                <?php echo e(Form::open(array('action' => array('ArticuloController@destroy', $art -> id_articulo), 'method' => 'delete'))); ?>

                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                                                             <div class="form-group">            
                                                                               <center><p>¿estas seguro que desea eliminar este producto?</p></center>          
                                                                            </div>
                                                                        </div>
                                                                    </div> 
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Cancelar</button>
                                                                    
                                                                    <button type="submit" class="btn btn-danger waves-effect waves-light">Eliminar</button>
                                                                </div>
                                                                <?php echo e(Form::close()); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- ============================================================== -->
                                                <!-- End modal Content --> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->



                <!-- Model Nuevo Articulo -->
                <!-- ============================================================== -->
                <div class="col-md-4">
                                <!-- sample modal content -->
                                <div id="modalcrear" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                <h4 class="modal-title">Crear nuevo articulo</h4>
                                            </div>
                                            <?php if(count($errors) > 0): ?>
                                            <div class="alert alert-danger">
                                                <ul>
                                                    <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                            <?php endif; ?>
                                            <form action=" <?php echo e(url('almacen/articulo')); ?>" method="POST" enctype="multipart/form-data" class="form-material m-t-40">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                                         <div class="form-group">            
                                                           <label for="nombre">Nombre:</label>
                                                            <input type="text" class="form-control" name="nombre" placeholder="Nombre..." required value="<?php echo e(old('nombre')); ?>">            
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                                         <div class="form-group">            
                                                           <label for="nombre">Categoria:</label>
                                                           <select name="id_categoria" id="" class="form-control">
                                                              <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                               <option value="<?php echo e($cat -> id_categoria); ?>"><?php echo e($cat -> nombre); ?></option>
                                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                           </select>
                                                    </div>
                                                    </div>
                                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                                        <div class="form-group">            
                                                           <label for="codigo">Codigo:</label>
                                                            <input type="text" class="form-control" name="codigo" placeholder="Codigo..." required value="<?php echo e(old('codigo')); ?>">            
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                                         <div class="form-group">            
                                                           <label for="stock">Stock:</label>
                                                            <input type="text" class="form-control" name="stock" placeholder="Stock..." required value="<?php echo e(old('stock')); ?>">            
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                                         <div class="form-group">            
                                                           <label for="stock">Precio de venta:</label>
                                                            <input type="text" class="form-control" name="precio_venta" placeholder="Precio venta..." required value="<?php echo e(old('precio_venta')); ?>">            
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                                         <div class="form-group">            
                                                           <label for="imagen">Imagen:</label>                
                                                            <input type="file" class="form-control" name="imagen">            
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                                         <div class="form-group">            
                                                           <label for="descripcion">Descripcion:</label>
                                                           <textarea type="text" class="form-control" name="descripcion" placeholder="Descripcion..."  value="<?php echo e(old('descripcion')); ?>"></textarea>            
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Cerrar</button>
                                                <button type="submit" class="btn btn-danger waves-effect waves-light">Guardar</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                <!-- ============================================================== -->
                <!-- End modal Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>