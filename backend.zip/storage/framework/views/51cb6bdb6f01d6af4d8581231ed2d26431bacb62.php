 
 <?php $__env->startSection('content'); ?>
 <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Articulo</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item active">Editar Articulo</li>
                        </ol>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                                <div class="row">
                                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                      <h3>Editar Articulo: <?php echo e($articulo -> nombre); ?></h3>
                                      <?php if(count($errors) > 0): ?>
                                      <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                      </div>
                                      <?php endif; ?>
                                  </div>
                              </div>       
        
                              <?php echo e(Form::model($articulo, ['method' => 'PATCH', 'route' => ['articulo.update', $articulo -> id_articulo], 'files' => 'true'])); ?>

                              <?php echo e(Form::token()); ?>

                              <div class="row">
                              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                   <div class="form-group">            
                                     <label for="nombre">Nombre:</label>
                                      <input type="text" class="form-control" name="nombre" placeholder="Nombre..." required value="<?php echo e($articulo -> nombre); ?>">            
                                  </div>
                              </div>
                              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                   <div class="form-group">            
                                     <label for="nombre">Categoria:</label>
                                     <select name="id_categoria" id="" class="form-control">
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cat ->id_categoria == $articulo -> id_categoria): ?>
                                                 <option value="<?php echo e($cat -> id_categoria); ?>" selected><?php echo e($cat -> nombre); ?></option>
                                          <?php else: ?>
                                                  <option value="<?php echo e($cat -> id_categoria); ?>" ><?php echo e($cat -> nombre); ?></option>
                                          <?php endif; ?>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                              </div>
                              </div>
                              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                  <div class="form-group">            
                                     <label for="codigo">Codigo:</label>
                                      <input type="text" class="form-control" name="codigo"  required value="<?php echo e($articulo->codigo); ?>">            
                                  </div>
                              </div>
                              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                   <div class="form-group">            
                                     <label for="stock">Stock:</label>
                                      <input type="text" class="form-control" name="stock"  required value="<?php echo e($articulo->stock); ?>">          
                                  </div>
                              </div>
                              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                   <div class="form-group">            
                                     <label for="stock">Precio de venta:</label>
                                      <input type="text" class="form-control" name="precio_venta"  required value="<?php echo e($articulo->precio_venta); ?>">          
                                  </div>
                              </div>
                              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                   <div class="form-group">            
                                     <label for="descripcion">Descripcion:</label>
                                     <textarea name="descripcion" id="textarea" class="form-control"  placeholder="ingrese la descripcion"><?php echo e($articulo->descripcion); ?></textarea>        
                                  </div>
                              </div>
                              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                   <div class="form-group">               
                                      <input type="file" class="form-control" name="imagen">            
                                      <?php if(($articulo-> imagen) != ""): ?>
                                          <img src="<?php echo e(asset('imagenes/articulos/'.$articulo->imagen)); ?>" alt="imagen" style="height: 150px; width:200px; background-size: contain;">
                                      <?php endif; ?>
                                  </div>
                              </div>
                              <br><br><br>
                              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                  <button class="btn btn-lg btn-outline-primary btn-rounded" type="submit">Reset</button>
                                  <button class="btn btn-lg btn-outline-success btn-rounded" type="submit">Actualizar</button>
                                  </div>  
                              </div>
                          </div> 
                          <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </div>
              </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>